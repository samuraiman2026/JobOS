// Job Search OS — Popup Script v2
'use strict';

const STORAGE_KEY     = 'jobos_ext_v1';
const OUTREACH_KEY    = 'jobos_outreach_sync';
const GIST_KEY        = 'jobos_gist_url';
const NUDGE_DAYS      = 10;

let jobData  = null;
let prompts  = {};
let profile  = null; // loaded from Gist or fallback

// ── HARDCODED FALLBACK PROFILE ────────────────────────
const FALLBACK_PROFILE = {
  name: 'Pranjal Mahna',
  background: 'Huawei (0-to-1 ISV ecosystem, 1,000+ partners, $1M→$100M revenue, Kirin 9000/Edge AI, 2x President\'s Award), Qualia (API BD, $20M pipeline, $9M at 120%, 60% win rate, first BD hire), Pandora ($155M/$40M/$10M new channels, OEM: Sony/Samsung/Honda), Mobclix ($16M, 185% YoY), Sony Mobile (first $10M, 16 markets), PMSV advisory, BTech/Bell Labs.',
  stories: { A:'Huawei ISV ($1M→$100M)', B:'Qualia API BD ($9M 120%)', C:'Pandora OEM ($200M+)', D:'PMSV+AI Stack', E:'Sony/Mobclix' },
  bulletMap: {
    hardware:   'Lead with: Pandora OEM (Sony/Samsung/Honda), Huawei Kirin 9000 on-device AI.',
    enterprise: 'Lead with: Huawei ISV 1,000+ at scale, GTM infrastructure, exec stakeholder bullets.',
    startup:    'Lead with: Qualia "first BD hire" $9M 120%, Wove 90-day first 3 partners.',
    supply:     'Lead with: Mobclix 185% YoY $16M 30B impressions, Pandora remnant $35M.',
    alliances:  'Lead with: Huawei portfolio management (competing/complementary), Qualia governance.',
    privacy:    'Lead with: Huawei on-device AI local inference, Qualia compliance complexity.'
  }
};

// ── INIT ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadProfile();
  loadHistory();
  await detectJobPage();
  await loadNudges();
  loadGistConfig();
  loadExportCount();
});

// ── GIST PROFILE SYNC ────────────────────────────────
async function loadProfile() {
  return new Promise(resolve => {
    chrome.storage.local.get(GIST_KEY, async data => {
      const gistUrl = data[GIST_KEY];
      if (!gistUrl) {
        profile = FALLBACK_PROFILE;
        resolve();
        return;
      }
      try {
        const resp = await fetch(gistUrl, { cache: 'no-store' });
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const json = await resp.json();
        profile = { ...FALLBACK_PROFILE, ...json };
        resolve();
      } catch(e) {
        profile = FALLBACK_PROFILE;
        resolve();
      }
    });
  });
}

function loadGistConfig() {
  chrome.storage.local.get(GIST_KEY, data => {
    const url = data[GIST_KEY] || '';
    const el = document.getElementById('gist-url');
    const statusEl = document.getElementById('gist-status');
    if (el) el.value = url;
    if (statusEl) {
      if (url) {
        statusEl.innerHTML = `<span class="g-ok">● Profile loaded from Gist</span>`;
      } else {
        statusEl.innerHTML = `<span class="g-loading">○ Using hardcoded fallback — enter Gist URL to enable live sync</span>`;
      }
    }
  });
}

function saveGistUrl() {
  const url = document.getElementById('gist-url').value.trim();
  chrome.storage.local.set({ [GIST_KEY]: url }, async () => {
    if (url) {
      const statusEl = document.getElementById('gist-status');
      statusEl.innerHTML = `<span class="g-loading"><span class="spinner"></span>Testing...</span>`;
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const json = await resp.json();
        profile = { ...FALLBACK_PROFILE, ...json };
        statusEl.innerHTML = `<span class="g-ok">● Connected — profile synced from Gist</span>`;
        toast('Gist profile loaded ✓');
      } catch(e) {
        document.getElementById('gist-status').innerHTML = `<span class="g-err">✗ Could not fetch — check URL and make sure it's a raw Gist link</span>`;
      }
    } else {
      loadGistConfig();
      toast('Gist URL cleared — using fallback');
    }
  });
}

// ── PAGE DETECTION ────────────────────────────────────
async function detectJobPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  const url = tab.url || '';
  document.getElementById('site-url').textContent = url.replace('https://','').substring(0,46) + (url.length > 46 ? '…' : '');

  const jobSites = {
    'linkedin.com':  { icon:'in', label:'LinkedIn' },
    'greenhouse.io': { icon:'gh', label:'Greenhouse' },
    'lever.co':      { icon:'lv', label:'Lever' },
    'ashbyhq.com':   { icon:'ab', label:'Ashby' },
    'indeed.com':    { icon:'in', label:'Indeed' },
    'glassdoor.com': { icon:'gd', label:'Glassdoor' },
    'wellfound.com': { icon:'wf', label:'Wellfound' },
    'builtin.com':   { icon:'bt', label:'Built In' }
  };

  let isJobSite = false;
  for (const [domain, info] of Object.entries(jobSites)) {
    if (url.includes(domain)) {
      document.getElementById('site-icon').textContent = info.icon;
      document.getElementById('site-status').innerHTML = `<span class="s-ok">● ${info.label}</span>`;
      isJobSite = true;
      break;
    }
  }
  if (!isJobSite) {
    document.getElementById('site-icon').textContent = '?';
    document.getElementById('site-status').innerHTML = `<span class="s-warn">● unknown</span>`;
  }

  document.getElementById('score-loading').style.display = 'block';
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'extractJob' });
    document.getElementById('score-loading').style.display = 'none';
    if (response && (response.title || response.jobText)) {
      jobData = response;
      showJobDetected(response);
      autoScore(response);
    } else {
      showNoJob();
    }
  } catch(e) {
    document.getElementById('score-loading').style.display = 'none';
    showNoJob();
  }
}

function showJobDetected(data) {
  const bar = document.getElementById('job-bar');
  bar.style.display = 'block';
  document.getElementById('job-title-d').textContent = data.title || 'Job posting detected';
  document.getElementById('job-co-d').textContent    = data.company || data.url;
  document.getElementById('job-src').textContent     = data.source;
}

function showNoJob() {
  document.getElementById('score-no-job').style.display = 'block';
  document.getElementById('score-content').style.display = 'none';
}

// ── SCORING ───────────────────────────────────────────
function autoScore(data) {
  const jd = ((data.title||'') + ' ' + (data.company||'') + ' ' + (data.jobText||'')).toLowerCase();
  runScoreEngine(jd, data.title, data.company);
}

function scoreManual() {
  const jd      = document.getElementById('manual-jd').value.trim();
  const company = document.getElementById('manual-company').value.trim();
  if (!jd && !company) { toast('Paste a JD to score'); return; }
  jobData = { title: company.split('—')[1]?.trim() || '', company: company.split('—')[0].trim(), jobText: jd, source: 'manual', url: '' };
  showJobDetected(jobData);
  runScoreEngine((jd+' '+company).toLowerCase(), jobData.title, jobData.company);
}

function runScoreEngine(jdText, title, company) {
  const s1 = scoreKw(jdText, ['ecosystem','partner','isv','marketplace','developer','sdk','platform','alliance','channel','go-to-market','gtm','integration','co-sell','distribution']);
  const s2 = scoreKw(jdText, ['build','create','launch','from scratch','establish','first','greenfield','new','stand up','0 to 1','zero to one','founding','incubate']);
  const s3 = scoreKw(jdText, ['technical','engineering','api','integration','sdk','architecture','infrastructure','protocol','developer','product','saas']);
  const s4 = scoreKw(jdText, ['ai','artificial intelligence','ml','machine learning','llm','edge','on-device','genai','model','intelligent','deep learning','neural']);
  const s5 = scoreKw(jdText, ['director','senior manager','vp','vice president','lead','head of','strategic','executive','global','principal']);
  const total = Math.round(s1*.25 + s2*.25 + s3*.20 + s4*.20 + s5*.10);

  document.getElementById('score-no-job').style.display  = 'none';
  document.getElementById('score-content').style.display = 'block';

  setTimeout(() => {
    anim('p-sf1','p-sp1',s1); anim('p-sf2','p-sp2',s2); anim('p-sf3','p-sp3',s3);
    anim('p-sf4','p-sp4',s4); anim('p-sf5','p-sp5',s5);

    const te = document.getElementById('p-total');
    te.textContent = total + '%';
    te.className = 'score-num ' + (total>=75?'strong':total>=50?'mid':'weak');

    const ve = document.getElementById('p-verdict');
    ve.innerHTML = total>=75 ? '<span class="vtag v-apply">✓ Apply now</span>'
      : total>=50 ? '<span class="vtag v-consider">○ Consider</span>'
      : '<span class="vtag v-skip">✗ Skip</span>';

    document.getElementById('p-angles').innerHTML = buildAngles(jdText);
    document.getElementById('sync-row').style.display = 'block';

    prompts.score = buildScorePrompt(title, company, jobData?.jobText || jdText);
    saveScore(company + (title ? ' — ' + title : ''), total);
    logUsage('/score', (company||'Unknown') + (title ? ' — '+title : ''));
  }, 100);
}

function scoreKw(text, kws) {
  const hits = kws.filter(k => text.includes(k)).length;
  return Math.round(50 + Math.min(hits / Math.max(kws.length * 0.35, 1), 1) * 50);
}

function anim(fId, pId, val) {
  document.getElementById(fId).style.width = val + '%';
  document.getElementById(pId).textContent = val + '%';
}

function buildAngles(jd) {
  const pos=[], neg=[];
  if (jd.includes('ecosystem')||jd.includes('isv')||jd.includes('platform')) pos.push('Ecosystem builder match — Huawei ISV program is direct proof');
  if (jd.includes('0 to 1')||jd.includes('from scratch')||jd.includes('founding')||jd.includes('build')) pos.push('0-to-1 builder signal — Qualia first BD hire maps perfectly');
  if (jd.includes('ai')||jd.includes('on-device')||jd.includes('edge')) pos.push('AI/Edge AI angle — Kirin 9000 on-device partnerships are the differentiator');
  if (jd.includes('hardware')||jd.includes('device')||jd.includes('oem')) pos.push('Hardware/OEM — Pandora OEM (Sony, Samsung, Honda) is underused here');
  if (jd.includes('saas')&&!jd.includes('enterprise')) neg.push('SaaS-only framing — emphasize API-first BD (Qualia) over platform');
  if (jd.includes('sales')&&!jd.includes('partnership')) neg.push('Sales-heavy JD — reframe as partner-assisted and ecosystem revenue');
  if (!jd.includes('partner')&&!jd.includes('ecosystem')) neg.push('Light partnership language — verify role type before applying');
  return (pos.length?'<span class="a-pos">+ </span>'+pos.join('<br><span class="a-pos">+ </span>'):'') +
    (neg.length?'<br><span class="a-neg">− </span>'+neg.join('<br><span class="a-neg">− </span>'):'');
}

// ── PROMPT BUILDERS ───────────────────────────────────
function buildScorePrompt(title, company, jd) {
  const bg = profile?.background || FALLBACK_PROFILE.background;
  return `Score this JD against my BD/Partnerships profile.\n\nMy background: ${bg}\n\n${company?'Company: '+company:''}${title?'\nRole: '+title:''}\n${jd?'\nJD:\n'+jd.substring(0,3000):''}\n\nScore 1-10 on each (show visual bars):\n1. Ecosystem/partner motion match (25%)\n2. 0-to-1 builder requirement (25%)\n3. Technical BD depth needed (20%)\n4. AI-native/Edge AI angle (20%)\n5. Seniority and scope match (10%)\n\nOverall weighted score + verdict: apply now / apply with bridge / pass.\nMy 2 strongest angles + biggest gap for this specific role.`;
}

function generateApply() {
  if (!jobData && !document.getElementById('manual-jd').value) { toast('Navigate to a job page first'); return; }
  const type    = document.getElementById('p-apply-type').value;
  const contact = document.getElementById('p-apply-contact').value;
  const role    = jobData ? `${jobData.company} — ${jobData.title}` : 'this role';
  const jd      = jobData?.jobText || '';
  const bg      = profile?.background || FALLBACK_PROFILE.background;
  const bm      = profile?.bulletMap?.[type] || FALLBACK_PROFILE.bulletMap[type] || '';

  prompts.apply = `Run my full BD/Partnerships application workflow.\n\nRole: ${role}\n${jd?'JD:\n'+jd.substring(0,2500):''}\n\nMy background: ${bg}\n\nBullet selection (${type}): ${bm}\n\nContact: ${contact==='none'?'No warm contact — cold referral strategy needed':contact==='weak'?'Weak 2nd-degree — warm outreach angle needed':'Strong 1st-degree contact — referral path available'}\n\nDeliver: (1) JD analysis, (2) resume restructure 4-5 bullets per role, (3) gap bridge, (4) referral strategy, (5) cover note with one specific hook.`;

  const el = document.getElementById('apply-out');
  el.textContent = prompts.apply;
  el.style.display = 'block';
  document.getElementById('apply-copy').style.display = 'flex';
  logUsage('/apply', role);
  toast('Application prompt ready');
}

function generateBrief() {
  const pipeline  = document.getElementById('p-brief-pipeline').value.trim();
  const followups = document.getElementById('p-brief-followups').value.trim();
  prompts.brief = `Good morning. Run my daily BD/Partnerships job search briefing.\n\nMy pipeline:\n${pipeline||'Nothing.tech — awaiting HM scheduling\nMicrosoft — applied, seeking referral\nEmissary — active conversations\nTuring — monitoring'}\n\nPending follow-ups:\n${followups||'None flagged'}\n\nGenerate:\n1. Top 3 actions for today, ranked by impact — flag anything time-sensitive\n2. Any roles going cold that need immediate action\n3. Referral outreach I should send today\n4. One-line status on each active role\n\nKeep it to a 90-second read. Game plan, not a report.`;
  const el = document.getElementById('brief-out');
  el.textContent = prompts.brief;
  el.style.display = 'block';
  document.getElementById('brief-copy').style.display = 'flex';
  logUsage('/brief', 'Morning briefing');
  toast('Briefing prompt ready');
}

// ── OUTREACH TRACKER SYNC ─────────────────────────────
function syncToTracker() {
  if (!jobData) { toast('No job data to sync'); return; }
  const company = jobData.company || 'Unknown';
  const role    = jobData.title   || '';
  const total   = parseInt(document.getElementById('p-total').textContent) || 0;
  const pov     = `Scored ${total}% via Chrome extension on ${new Date().toLocaleDateString()}`;

  chrome.runtime.sendMessage({ action: 'syncOutreach', data: { company, role, score: total, pov } }, resp => {
    if (resp?.added) {
      toast(`${company} added to outreach tracker ✓`);
      document.getElementById('sync-btn').textContent = '✓ Added to tracker';
      document.getElementById('sync-btn').disabled = true;
      loadExportCount();
      logUsage('/outreach-sync', company);
    } else {
      toast(`${company} already in tracker`);
      document.getElementById('sync-btn').textContent = '✓ Already in tracker';
      document.getElementById('sync-btn').disabled = true;
    }
  });
}

function loadExportCount() {
  chrome.storage.local.get(OUTREACH_KEY, data => {
    const contacts = data[OUTREACH_KEY]?.contacts || [];
    const el = document.getElementById('export-count');
    const subEl = document.getElementById('export-sub');
    if (el) el.textContent = contacts.length;
    if (subEl) subEl.textContent = contacts.length === 0
      ? 'No roles synced yet. Score a role on LinkedIn and click "+ Add to outreach tracker".'
      : `${contacts.length} role${contacts.length===1?'':'s'} scored and queued. Export JSON to import into the OS dashboard outreach tracker.`;
  });
}

function exportToOS() {
  chrome.storage.local.get(OUTREACH_KEY, data => {
    const contacts = data[OUTREACH_KEY]?.contacts || [];
    if (!contacts.length) { toast('No roles to export yet'); return; }
    const json = JSON.stringify({ contacts, exportedAt: new Date().toISOString() }, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    chrome.downloads.download({
      url, filename: `jobos-scored-roles-${new Date().toISOString().split('T')[0]}.json`,
      saveAs: true
    }).catch(() => {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(json).then(() => toast('JSON copied — paste into OS import'));
    });
    toast(`Exporting ${contacts.length} roles…`);
    logUsage('/export', contacts.length + ' roles');
  });
}

// ── NUDGE ALERTS ──────────────────────────────────────
async function loadNudges() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'getOverdueContacts' }, resp => {
      const overdue = resp?.overdue || [];
      renderNudges(overdue);
      updateNudgeBadge(overdue.length);
      resolve();
    });
  });
}

function renderNudges(overdue) {
  const list = document.getElementById('nudge-list');
  const banner = document.getElementById('nudge-banner');
  const bannerText = document.getElementById('nudge-banner-text');

  if (!overdue.length) {
    list.innerHTML = `<div style="text-align:center;padding:20px 14px;"><div style="font-family:var(--mono);font-size:20px;color:var(--text3);margin-bottom:8px;">✓</div><div style="font-size:12px;color:var(--text2);">No overdue follow-ups.</div><div style="font-size:11px;color:var(--text3);margin-top:6px;">Contacts reached out within ${NUDGE_DAYS} days are on track.</div></div>`;
    banner.style.display = 'none';
    return;
  }

  // Show banner
  banner.style.display = 'block';
  bannerText.textContent = `⚠ ${overdue.length} follow-up${overdue.length===1?'':'s'} overdue — click to review`;

  list.innerHTML = overdue.map((c, i) => `
    <div class="nudge-item" id="nudge-${i}">
      <div class="nudge-co">${c.company}</div>
      ${c.role ? `<div class="nudge-meta">${c.role}</div>` : ''}
      ${c.contact ? `<div class="nudge-meta">Contact: ${c.contact}</div>` : ''}
      <div class="nudge-days">Last outreach: ${c.lastOutreach || 'unknown'} — ${c.daysSince} days ago</div>
      <div class="nudge-btns">
        <button class="nudge-btn nb-copy" onclick="copyNudgePrompt(${i})">Copy nudge →</button>
        <button class="nudge-btn nb-done" onclick="markNudgeDone(${i}, '${c.company}')">Mark sent</button>
      </div>
    </div>`).join('');

  // Store for reference
  window._nudges = overdue;
}

function copyNudgePrompt(i) {
  const c = window._nudges?.[i];
  if (!c) return;
  const prompt = `Write a brief, warm follow-up message for ${c.company}${c.contact ? ' (contact: '+c.contact+')' : ''}.

Last outreach: ${c.lastOutreach || 'unknown'} (${c.daysSince} days ago)
${c.role ? 'Role: '+c.role : ''}
${c.pov ? 'My angle: '+c.pov : ''}

Requirements:
— Under 60 words
— Reference something specific about ${c.company} or our last interaction if possible
— Does NOT say "just checking in" or "following up on my previous message"
— Adds value — share a recent insight about their space, a relevant metric, or a specific question
— Ends with a clear but low-pressure ask

My background (for context): Huawei ISV ecosystem ($1M→$100M), Qualia first BD hire ($9M at 120%), Pandora OEM.`;

  navigator.clipboard.writeText(prompt).then(() => {
    toast(`Nudge prompt for ${c.company} copied`);
    logUsage('/nudge', c.company);
  });
}

function markNudgeDone(i, company) {
  const today = new Date().toLocaleDateString('en-US', { month:'short', day:'numeric' });
  // Update in storage
  chrome.storage.local.get(OUTREACH_KEY, data => {
    const contacts = data[OUTREACH_KEY]?.contacts || [];
    const c = contacts.find(x => x.company?.toLowerCase() === company.toLowerCase());
    if (c) {
      c.lastOutreach = today;
      c.status = c.status === 'Reached Out' ? 'Follow-up Sent' : 'Reached Out';
    }
    chrome.storage.local.set({ [OUTREACH_KEY]: { ...data[OUTREACH_KEY], contacts } }, () => {
      const el = document.getElementById(`nudge-${i}`);
      if (el) el.style.opacity = '0.4';
      toast(`${company} — nudge logged for ${today}`);
      logUsage('/nudge-done', company);
      // Refresh badge
      loadNudges();
    });
  });
}

function updateNudgeBadge(count) {
  const badge = document.getElementById('nudge-badge');
  const tab   = document.getElementById('tab-nudges');
  if (!badge || !tab) return;
  if (count > 0) {
    badge.textContent = count;
    badge.style.display = 'block';
  } else {
    badge.style.display = 'none';
  }
}

// ── SHORTCUTS ─────────────────────────────────────────
const SHORTCUT_PROMPTS = {
  referral: () => {
    const role = jobData ? `${jobData.company} — ${jobData.title}` : '[paste role here]';
    return `Build a referral-first strategy for: ${role}\n\nMy network: Ex-Huawei ISV partners (Pinterest, Shazam, Meta, Adobe, Airbnb), Qualia fintech network, Pandora OEM (Sony, Samsung, Honda), PMSV advisory clients, AI Collective alumni, Pavilion GTM community.\n\nGenerate: (1) who to reach out to, (2) the right angle, (3) LinkedIn DM under 80 words — specific to this company, (4) timing, (5) follow-up plan if no reply in 5 days.`;
  },
  prep: () => {
    const role = jobData ? `${jobData.company} — ${jobData.title}` : '[role here]';
    return `Run my full BD/Partnerships interview prep for: ${role}\n\nPlease search the web for recent news about this company and the interviewer if a name is available.\n\nGenerate: (1) what this company actually cares about right now, (2) 10 BD-specific questions — partner motion, deal structure, ecosystem GTM, channel conflict, metrics, (3) for each question: best story to use, (4) 3 gap bridge narratives, (5) "tell me about yourself" specifically for this company.`;
  },
  mock: () => `Mock interview mode. Role: ${jobData ? jobData.company+' — '+jobData.title : '[role]'}\n\nAsk me the 3 hardest BD/partnerships questions for this role. One at a time. Wait for my answer. After each: score Relevance (1-5), Specificity (1-5), Impact clarity (1-5). Tell me what landed, what to fix, which story to use. Then ask: ready for next question?\n\nMy stories: A=Huawei ISV ($1M→$100M), B=Qualia API BD ($9M 120%), C=Pandora OEM ($200M+), D=PMSV+AI Stack, E=Sony/Mobclix.`,
  debrief: () => `Post-interview debrief.\n\nInterview: [company — role — interviewer name/title]\nQuestions asked:\n1. [question]\n2. [question]\n3. [question]\nKey moments: [what you noticed]\nGut read: [positive / mixed / concerned]\n\nScore each answer: Relevance (1-5), Specificity (1-5), Impact clarity (1-5). Find the 2-3 moments I left value on the table with rewrites. Draft a personalized thank-you email referencing what we actually discussed.`,
  negotiate: () => `Build my negotiation strategy.\n\nRole: [company — role]\nOffer: Base $[X] | Bonus [%] | Equity [details] | Signing $[X]\nCompeting: [yes/no] | Want this role: [1-10]/10\n\nMy leverage: Huawei $1M→$100M ecosystem + 2x President's Award, Qualia $9M at 120% as first BD hire, PMSV advisory currently active (not unemployed), BTech + Bell Labs technical depth.\n\nSearch web for current comp benchmarks. Then: (1) market data, (2) my 3 leverage points, (3) counter offer, (4) exact call script, (5) response if they say "best offer."`,
  pattern: () => `Analyze my BD/Partnerships interview patterns.\n\n[Paste debrief history here]\n\nIdentify: (1) question types I score low on consistently, (2) question types I score high on, (3) specific weaknesses, (4) which story I over-rely on, (5) Pandora OEM story — am I using it for hardware roles?, (6) drill plan for next interview.`,
  'hiring-manager': () => `You are a VP of Partnerships who has hired 20+ BD professionals. Review this material as a hiring manager — 6-second scan, skeptical lens.\n\n[Paste resume, cover note, or answer here]\n\nGive me: (1) first impression in 6 seconds, (2) what's working — top 3, (3) what's not working — top 3 with fixes, (4) one bullet to rewrite immediately, (5) verdict: HIRE / STRONG MAYBE / MAYBE / NOT YET.`,
  skeptic: () => `Make the strongest possible case against hiring me for: ${jobData ? jobData.company+' — '+jobData.title : '[this role]'}\n\nMy background: Huawei ISV ecosystem, Qualia API BD, Pandora, Mobclix, Sony Mobile, PMSV advisory, BTech/Bell Labs.\n\nFor each concern: what triggers it, how serious (1-5), and the exact bridge narrative. Then: the hardest question a skeptical interviewer would ask, and what I absolutely cannot say.`
};

function quickCmd(cmd) {
  const prompt = SHORTCUT_PROMPTS[cmd]?.();
  if (!prompt) return;
  navigator.clipboard.writeText(prompt).then(() => {
    toast(cmd + ' prompt copied — paste into Claude');
    logUsage('/'+cmd, jobData ? jobData.company : 'quick command');
  });
}

// ── CLAUDE / COPY ─────────────────────────────────────
function openClaude(type) {
  const prompt = prompts[type] || '';
  if (!prompt) { toast('Generate a prompt first'); return; }
  navigator.clipboard.writeText(prompt).then(() => {
    chrome.tabs.create({ url: 'https://claude.ai/new' });
    toast('Prompt copied — paste it in Claude');
  });
}

function copyP(type) {
  const prompt = prompts[type] || '';
  if (!prompt) { toast('Generate a prompt first'); return; }
  navigator.clipboard.writeText(prompt).then(() => toast('Copied to clipboard'));
}

function openOSApp() {
  chrome.tabs.create({ url: 'https://claude.ai' });
}

// ── STORAGE ───────────────────────────────────────────
function loadState() {
  return new Promise(resolve => {
    chrome.storage.local.get(STORAGE_KEY, data => {
      resolve(data[STORAGE_KEY] || { history:[], scores:[], stats:{ total:0, streak:0, lastDate:null } });
    });
  });
}
function saveState(state) { chrome.storage.local.set({ [STORAGE_KEY]: state }); }

function logUsage(cmd, detail) {
  loadState().then(state => {
    const now = new Date();
    state.history.unshift({
      cmd, detail,
      date: now.toLocaleDateString('en-US',{month:'short',day:'numeric'}),
      time: now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}),
      ts:   now.toISOString()
    });
    if (state.history.length > 100) state.history = state.history.slice(0,100);
    state.stats.total = (state.stats.total||0) + 1;
    const today = now.toISOString().split('T')[0];
    if (state.stats.lastDate !== today) {
      const yest = new Date(now - 86400000).toISOString().split('T')[0];
      state.stats.streak = state.stats.lastDate === yest ? (state.stats.streak||0)+1 : 1;
      state.stats.lastDate = today;
    }
    saveState(state);
    renderHistory(state);
  });
}

function saveScore(company, score) {
  loadState().then(state => {
    state.scores = state.scores || [];
    state.scores.unshift({ company, score, date: new Date().toLocaleDateString('en-US',{month:'short',day:'numeric'}) });
    if (state.scores.length > 50) state.scores = state.scores.slice(0,50);
    saveState(state);
  });
}

function loadHistory() { loadState().then(renderHistory); }

function renderHistory(state) {
  if (!state) return;
  const today      = new Date().toISOString().split('T')[0];
  const todayCount = (state.history||[]).filter(h => h.ts?.startsWith(today)).length;
  document.getElementById('h-total').textContent  = state.stats?.total  || 0;
  document.getElementById('h-today').textContent  = todayCount;
  document.getElementById('h-scored').textContent = (state.scores||[]).length;
  document.getElementById('h-streak').textContent = (state.stats?.streak||0) + 'd';
  const el   = document.getElementById('history-items');
  const hist = state.history || [];
  if (!hist.length) {
    el.innerHTML = '<div style="font-family:var(--mono);font-size:10px;color:var(--text3);padding:10px 0;">No activity yet.</div>';
    return;
  }
  el.innerHTML = hist.slice(0,12).map(h => `
    <div class="hist-item">
      <div class="h-cmd">${h.cmd}</div>
      <div class="h-detail">${h.detail}</div>
      <div class="h-time">${h.date}</div>
    </div>`).join('');
}

// ── TABS ──────────────────────────────────────────────
function switchTab(id) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-'+id).classList.add('active');
  document.getElementById('panel-'+id).classList.add('active');
  if (id === 'history') loadHistory();
  if (id === 'nudges')  { loadNudges(); loadExportCount(); loadGistConfig(); }
}

// ── TOAST ─────────────────────────────────────────────
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2200);
}
